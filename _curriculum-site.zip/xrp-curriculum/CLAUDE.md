# XRP Python Curriculum — Website Project

Context for anyone (human or AI) continuing work on this site. This is a
Docusaurus web version of Brad's XRP Python curriculum, styled like the
VEX STEM Labs lessons. **Read this first before making changes.**

---

## 1. What this project is

Turn the existing markdown curriculum (`../` — the `IntoToPython` repo) into a
browsable, VEX STEM Labs-style **website**: multi-page lessons with a sidebar,
prev/next navigation, embedded videos and graphics, interactive knowledge
checks, and a teacher-notes toggle.

- **Reference we're matching:** VEX AIR virtual-flight curriculum on
  education.vex.com (clean layout, teacher-notes switch, knowledge checks,
  media-rich lessons).
- **Audience:** high school students (no prior programming); teachers use the
  same pages with teacher-only notes toggled on.
- **Status (current):** **Module 1 (11 lessons) and Module 2 (10 lessons) are
  fully built** — 21 lessons live. **Modules 3–5 still to convert.**
  `docs/module-01-driving/lesson-01-meet-the-xrp.mdx` is the canonical template.
- **Blockly vs. Python by module:** Module 1 is the Blockly→Python arc (lessons
  1–7 use real Blockly block images; 8–11 are Python). **Module 2 onward is
  all Python** — plain ```python code blocks, no block images. Handy: the
  block-screenshot workflow (§6) only matters for Module 1.

## 2. Source content (what we convert from)

The curriculum content lives in the **parent repo** (`../`, `IntoToPython`):

- `../module-01-driving/` … `../module-05-dijkstra/`, each with:
  - `lessons/NN-*.md` — teacher lesson plans (objectives, key concepts, lesson flow, exercises, misconceptions, assessment)
  - `worksheets/NN-*.md` — student worksheets (great source for knowledge-check questions)
  - `code/starter/` and `code/solutions/` — Python/Blockly code
  - `slides/` — slide outlines + generated .pptx

**Content model (important):** we picked the **VEX model** — merge the teacher
lesson plan and the student worksheet into **one student-facing lesson page**,
and put teacher-only material (timing, setup tips, differentiation, assessment)
into `<TeacherNote>` boxes that only show when teacher mode is on. See
`docs/module-01-driving/lesson-01-meet-the-xrp.mdx` for the worked example —
copy its structure for new lessons.

## 3. Tech stack & layout

Docusaurus (classic preset, JavaScript). Docs are served at the site root
(`routeBasePath: '/'`).

```
curriculum-site/
├── docs/
│   ├── index.mdx                         # welcome / landing page (slug: /)
│   ├── module-01-driving/                # 11 lessons (Blockly→Python) — DONE
│   │   └── lesson-01-meet-the-xrp.mdx    # THE TEMPLATE lesson — copy its structure
│   └── module-02-line-tracking/          # 10 lessons (all Python) — DONE
│       └── lesson-NN-*.mdx               # (module 3–5 folders added as built)
├── src/
│   ├── components/
│   │   ├── Lesson.js      # LessonHeader, Objectives, TeacherBanner, CardGrid, InfoCard
│   │   ├── TeacherNote.js # gray teacher-only box
│   │   ├── KnowledgeCheck.js # interactive multiple-choice quiz
│   │   ├── Media.js       # Video, Figure (real src OR labeled placeholder)
│   │   └── Blocks.js      # Block (inline), BlockProgram (composed), BlockShot (real screenshot)
│   ├── theme/
│   │   ├── Root.js        # the floating Teacher-mode toggle + persistence
│   │   └── MDXComponents.js # registers all components globally (no imports needed in .mdx)
│   └── css/custom.css     # ALL styling + brand color tokens (top of file)
├── static/img/
│   ├── logo.svg
│   └── blocks/            # 91 real XRP Blockly block PNGs + programs/ real screenshots (see §6)
├── sidebars.js            # curriculum outline (modules → lessons)
├── docusaurus.config.js   # site config, navbar, Montserrat font, footer
├── netlify.toml           # deploy config (see §8)
└── README.md              # run + deploy instructions
```

MDX gotcha: don't put escaped double-quotes inside a JSX attribute string. For a
`KnowledgeCheck` question that must contain quotes (e.g. `print("hi")`), use a JS
expression: `question={'... print("hi") ...'}` — not `question="... \"hi\" ..."`.

## 4. Design system (XRP / Experiential Robotics brand)

Matched to **experiential.bot** (the official Experiential Robotics site). All
values are CSS tokens at the top of `src/css/custom.css` — change them there,
not inline.

| Role | Color |
|------|-------|
| Brand red — primary CTA, accents, links, knowledge-check badge, teacher toggle | `#D1182C` |
| Steel blue — navigation, lesson-header gradient start, section headings | `#22527B` |
| Deep navy — lesson-header gradient end | `#142D50` / `#0F2543` |
| Dark slate — body text, headings | `#343A40` |
| Light gray — section + teacher-note backgrounds | `#E9ECEF` / `#F8F9FA` |
| Success green (knowledge-check correct) | `#2E7D32` |

- **Font:** Montserrat (loaded via Google Fonts in `docusaurus.config.js`).
- **Lesson header:** blue→navy gradient band with red accent dots.
- **Shape language:** rounded corners (10–14px), generous whitespace, like VEX.
- Dark mode is supported (Docusaurus theme toggle) with a lighter blue primary.

## 5. Custom components (use these in lesson `.mdx`)

All are registered globally — **no import lines needed** in `.mdx` files.

```mdx
<LessonHeader
  eyebrow="Module 1 · Learning to Drive"
  title="Lesson 1 · Meet the XRP"
  meta={['50–60 min', 'Phase A · Blockly Foundation', 'No experience needed']} />

<TeacherBanner>Shown only in teacher mode — the "you're seeing teacher view" note.</TeacherBanner>

<Objectives>
- Bulleted learning objectives
</Objectives>

<TeacherNote title="Timing tip">
Gray box, hidden unless teacher mode is on. Teacher-only guidance.
</TeacherNote>

<KnowledgeCheck
  question="..."
  options={[
    {text: 'A wrong answer'},
    {text: 'The correct answer', correct: true},
    {text: 'Another wrong answer', feedback: 'Optional per-option hint'},
  ]}
  explanation="Shown after answering. Works for true/false too (just two options)." />

<Video placeholderLabel="Intro clip (1–2 min)" caption="..." />   {/* placeholder */}
<Video src="https://www.youtube.com/embed/XXXX" caption="..." />  {/* YouTube/Vimeo */}
<Video src="/videos/first-drive.mp4" mp4 caption="..." />         {/* local mp4 */}

<Figure placeholderLabel="Labeled diagram of the XRP" caption="..." />  {/* placeholder */}
<Figure src="/img/lesson-01/parts.png" alt="..." caption="..." />       {/* real image */}

<CardGrid>
  <InfoCard tag="Warehouses" title="Delivery robots">Real-world connection card.</InfoCard>
</CardGrid>
```

**Teacher mode** (Root.js): a floating switch (bottom-right) sets
`html[data-teacher='on']` and saves to `localStorage['xrp-teacher-mode']`.
`.teacherNote` and `.teacherBanner` are `display:none` by default and revealed
by that attribute (pure CSS). Default = student view.

## 6. Blockly blocks (real block images)

`static/img/blocks/` holds **all 91 real XRP Blockly block images**, taken from
the XRP User Guide's Blockly Dictionary (repo `Open-STEM/XRPUsersGuide`,
`course/blocks/*.png`). They were post-processed: the dark `#1F1F1F` workspace
background was flood-filled to transparent and each image auto-cropped tight, so
they float on a light canvas and interlock when stacked.

Render them with:

```mdx
The <Block name="straight" /> block drives in a straight line.   {/* inline */}

<BlockProgram
  blocks={[
    {name: 'straight', note: 'forward — cm: 20, Effort: 0.5'},
    {name: 'straight', note: 'back — change cm to -20'},
    {name: 'stop_motors'},
  ]}
  caption="A stacked program, like the real workspace." />
```

**Container / C-shaped blocks (Repeat, If, function def):** give the block a
`children` array. The component wraps those children in a colored C-bracket that
matches the block's category color (loops green, functions purple, if blue) — so
the contained blocks look genuinely *enclosed*, the way Blockly stretches a Repeat
to wrap its contents. Nest `children` inside `children` for a function that
contains a loop, etc. (Do NOT use a flat list with an `indent` field — that's the
old approach and it did not show enclosure.)

```mdx
<BlockProgram
  blocks={[
    {name: 'wait_for_button_press'},
    {name: 'repeat', note: 'repeat 4 times', children: [
      {name: 'straight', note: 'cm: 30'},
      {name: 'turn', note: 'Deg: 90'},
    ]},
  ]}
  caption="The Straight and Turn blocks sit inside the Repeat." />
```

**Real XRP block vocabulary (use these exact terms — NOT invented syntax):**

- **Straight** — `cm:` (distance; negative = backward), `Effort:` (0–1, not "power %"). Image: `straight.png`
- **Turn** — `Deg:` (angle), `Effort:` (0–1). Image: `turn.png`
- **Sleep** — seconds. Image: `sleep.png`
- **Stop motors**. Image: `stop_motors.png`
- Many more in `static/img/blocks/` (set_effort, arcade, LED_on, if_do, repeat, count, print1, variables, functions, sensors: sonar/reflectance/gyro, etc.) — filenames match the dictionary.

**Preferred for whole programs — real screenshots (`<BlockShot>`):** the composed
`BlockProgram` is an approximation (default field values, bracket-drawn nesting).
When Brad supplies a real screenshot of a program from XRP Code, use it instead —
it shows correct values and exact nesting. Save the PNG under
`static/img/blocks/programs/` and reference it:

```mdx
<BlockShot src="/img/blocks/programs/square-function.png"
  alt="square(side_length) function with a call passing 35"
  caption="The square(side_length) function and a call." />
```

XRP Code screenshots have a dark (#222) workspace background; whiten it before
use with an edge flood-fill (preserves the dark digits inside input fields):

```python
from PIL import Image, ImageDraw
im = Image.open('shot.png').convert('RGB'); w,h = im.size
for s in [(0,0),(w-1,0),(0,h-1),(w-1,h-1),(w//2,0),(w//2,h-1),(0,h//2),(w-1,h//2)]:
    ImageDraw.floodfill(im, s, (255,255,255), thresh=60)
im.save('out.png')
```

`static/img/blocks/programs/square-function.png` is the first real one (used in
Lesson 4). The composed `BlockProgram` remains in lessons 2, 3, 5, 7, 9 until real
screenshots replace them.

**Composed-block limitation:** `BlockProgram` images show fixed field values
(e.g. `cm: 20`); use the `note` prop for a different intended value.

## 7. Authoring a new lesson (the repeatable process)

1. Read the source `lessons/NN-*.md` and `worksheets/NN-*.md` in the parent repo.
2. Create `docs/module-XX-name/lesson-NN-slug.mdx` with frontmatter:
   ```
   ---
   title: "Lesson N · Title"
   sidebar_label: "N · Short Title"
   sidebar_position: N
   ---
   ```
3. Follow the Lesson 1 structure: `LessonHeader` → `TeacherBanner` → intro →
   `Objectives` → content sections (with `Video`/`Figure` placeholders and real
   `BlockProgram`s for any code) → `KnowledgeCheck`s built from the worksheet
   questions → `TeacherNote`s for teacher-only material → real-world `CardGrid`
   → wrap-up → Resources.
4. Add the page to `sidebars.js` (under its module category; replace the
   "Coming soon" placeholder as modules get built out).
5. Use **real block vocabulary** (§6) — Straight/Turn/Effort/Sleep, not power %.
6. `npm start` and eyeball it in both student and teacher mode.

## 8. Build, run, deploy

```bash
npm install     # first time
npm start       # dev server, live reload, http://localhost:3000
npm run build   # static site → build/
npm run serve   # preview the build
```

**Deploy: Netlify.** `netlify.toml` is set up. Two options:
- **Instant link:** `npm run build`, then drag `build/` onto app.netlify.com/drop.
- **Auto-deploy:** push this folder to GitHub, then in Netlify import the repo
  and set **Base directory = `curriculum-site`** (build command + publish path
  come from `netlify.toml`). Served at domain root, so `baseUrl` stays `/`.

(GitHub Pages also works but needs `baseUrl` = `/IntoToPython/` + a build workflow.)

## 9. Decisions already made (don't re-litigate without reason)

- **Framework:** Docusaurus (Brad had already started one; best fit for the interactive components).
- **Content model:** merge lesson plan + worksheet into one student page; teacher content in toggle-able gray boxes.
- **Branding:** XRP/Experiential palette + Montserrat (see §4), tokens in custom.css.
- **Blocks:** real images from the XRP User Guide, transparent + cropped; "Effort" not "power %". Prefer real `<BlockShot>` screenshots from Brad when available (§6).
- **Videos/graphics:** Brad produces them and hands them off; lessons use labeled placeholders until then.

**Open / unresolved:**
- **Naming inconsistency (Module 1):** most shape lessons use `draw_square` / `size`,
  but Lesson 4 uses `square` / `side_length` (matched to Brad's real screenshot).
  Not yet standardized — confirm with Brad before mass-renaming.
- **Block screenshots pending:** Brad is supplying real XRP Code screenshots to
  replace the composed `BlockProgram`s in Module 1 lessons 1, 2, 3, 5, 7, 9
  (Lesson 4 already done). Whiten + drop into `static/img/blocks/programs/`.

## 10. Good next steps

- **Module 3 · Grid Driving** (4 lessons: intro to the grid, driving multiple
  intersections, turning on the grid, final project) — reuses the `LineTrack`
  class from Module 2; all Python. **← next up.**
- Then **Module 4 · Manhattan** and **Module 5 · Dijkstra**.
- Swap the placeholder `logo.svg` if Brad provides an official XRP logo.
- Drop in real videos/graphics and block screenshots as Brad delivers them
  (replace `placeholderLabel` / add `src`; whiten screenshots per §6).

**Per-module pattern reminder:** each module is a `docs/module-XX-name/` folder of
`lesson-NN-slug.mdx` files, added to its category in `sidebars.js` (replace the
"Coming soon" placeholder link). Modules 2+ are all Python.

**To continue in a new session, a prompt like this is enough:**
"Continue the XRP curriculum site in `curriculum-site/`. Read CLAUDE.md, then
convert Module 3 following the established lesson template."
